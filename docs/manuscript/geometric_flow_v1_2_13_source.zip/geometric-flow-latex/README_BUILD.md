# Build Instructions — Geometric-Flow manuscript (disclosure revision)

Title: *Computation as Geometric Flow: An Arb-Certified Local Intrinsic ODE on a
Quantum-Control Response Fibre*

Author: Y. Y. N. Li

Expected compiled artifact: **`main.pdf`** — 21 pages, A4
(595.276 × 841.89 pt).

The distributed copy of that artifact is named
`geometric_flow_disclosure_revision.pdf`; it is a byte copy of `main.pdf`
produced by the build below.

## Nature of this revision

This is a **disclosure and notation revision only**, derived from the
`v1.2.12` freeze candidate. It does **not** change:

- any theorem, proposition, or corollary conclusion;
- any numerical constant, interval endpoint, or gate threshold;
- any SHA-256 identifier;
- any equation, theorem, or appendix numbering;
- the frozen v0.7.4 / v0.9.3 software and certificate boundary.

Seven textual items were changed: the frame-matrix spanning claim (§5), the
normal-box scope of the Krawczyk uniqueness statement (§5 and Theorem 1(i)),
the explicit `exp(-i tau H_j / 2)` propagator convention (§2.1), an additional
real-argument identification for the reflected analytic extension (§2.2),
disclosure of the two per-child sign gates (§9), disclosure of the
v0.9.3 / v0.7.4 reproduction asymmetry (§12), and clarification that
"subdivision 32" is an index rather than a count (§5, §6). No Arb, v0.7.4 or
v0.9.3 computation was rerun.

The title block carries no `\date` line; `\date{}` is set explicitly in
`main.tex`.

## TeX engine and version

The distributed PDF was produced with:

```
pdfTeX 3.141592653-2.6-1.40.25 (TeX Live 2023/Debian)
kpathsea version 6.3.5
LaTeX2e <2023-11-01> patch level 1
Producer string recorded in the PDF: pdfTeX-1.40.25
```

Any TeX Live 2023 or later distribution providing `pdflatex` and the packages
listed below is expected to reproduce the same 21-page document.

## Dependencies

No external `.bib` file, no images, and no local `.sty` or `.cls` file are
used. The bibliography is an inline `thebibliography` environment inside
`main.tex` with 18 entries, so **no BibTeX or Biber run is required**.

Required LaTeX packages, all part of a standard TeX Live installation
(`texlive-latex-base`, `texlive-latex-recommended`, `texlive-latex-extra`,
`texlive-fonts-recommended`):

| Package | Purpose |
| --- | --- |
| `graphicx` | loaded by the preamble; no image is included |
| `xcolor` | link colours |
| `geometry` | A4 page geometry |
| `amsmath`, `amssymb`, `amsthm` | mathematics and theorem environments |
| `booktabs` | rules in the gate and hash tables |
| `array` | table column formatting |
| `enumitem` | `(i)`, `(ii)`, … theorem item labels |
| `microtype` | micro-typography |
| `hyperref` | PDF metadata, bookmarks, coloured links |
| `xurl` | URL line breaking in the bibliography |

## Compilation command

Three `pdflatex` passes are required to resolve the cross-references,
theorem numbers, and hyperref bookmarks. There is no bibliography or index
pass.

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

Equivalently:

```bash
latexmk -pdf -interaction=nonstopmode main.tex
```

## Expected build result

After the third pass:

- `main.pdf`, 21 pages, A4;
- 0 overfull boxes, 0 underfull boxes;
- 0 undefined references, 0 undefined citations;
- 0 "Rerun to get cross-references right" requests;
- last displayed equation tag `(37)`;
- bibliography entries `[1]`–`[18]`.

## A note on byte-level reproducibility

`pdflatex` embeds `/CreationDate`, `/ModDate` and a time-derived `/ID` in the
output, so a rebuild produces a PDF that is **not byte-identical** to a
previously distributed one even when every source byte matches. The
reproducible quantities are the page count, the page size, the extracted text
layer, and every numerical constant and SHA-256 identifier in the document.

To obtain a deterministic PDF, fix the timestamp. With the epoch below and
the TeX Live 2023 engine named above, this bundle reproduces the distributed
artifact **byte for byte**:

```bash
export SOURCE_DATE_EPOCH=1786789922    # 2026-08-15 10:32:02 UTC
export FORCE_SOURCE_DATE=1
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # ×3
sha256sum main.pdf
# ac32035f2d0ead1db713e8724ad8838241a86dd61514712348955117207f92fa
```

Verified: a clean-room extraction of this bundle rebuilt under that epoch
matches the distributed `geometric_flow_disclosure_revision.pdf` at every
byte. Without `SOURCE_DATE_EPOCH`, exactly 68 bytes differ, all inside the
`/CreationDate`, `/ModDate` and `/ID` fields; the page count, page size and
text layer are unaffected.

## Files

See `SOURCE_MANIFEST.md` for the complete file list with SHA-256 digests.
`SOURCE_MANIFEST.md` excludes itself from the digest list to avoid a
self-hash loop.
