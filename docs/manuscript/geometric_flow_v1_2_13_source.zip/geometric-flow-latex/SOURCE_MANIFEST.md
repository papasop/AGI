# Source Manifest — Geometric-Flow manuscript (disclosure revision)

Bundle root: `geometric-flow-latex/`

Compiled artifact: `main.pdf` — 21 pages, A4.

`SOURCE_MANIFEST.md` lists every other file in the bundle. It excludes
itself from the digest list to avoid a self-hash loop.

Files listed: **16**

## Digests

| # | File | Bytes | SHA-256 |
| --- | --- | --- | --- |
| 1 | `README_BUILD.md` | 4896 | `a4a596623172f34da9f84d1a726c2a0801a1911d99394c15079b0140703ccc89` |
| 2 | `main.tex` | 5959 | `d0535e6e824075eedd423a8f4a0cdc46def34f7f9eb2591bdfffc7d297661570` |
| 3 | `sections/01_introduction.tex` | 6428 | `179f9cd79e82a0cd6a0b3059d2065b6438a83f4a1c47521720d5219488767468` |
| 4 | `sections/02_model.tex` | 6973 | `5c58659d4b4b2e91457cb1d52a0cc29bc64730ff627e806f2f3930e2eff80dda` |
| 5 | `sections/03_theorems.tex` | 6166 | `00275bf8e500774dba831ed3946590734c5d9cc8e4d1c72000997d56bca5d426` |
| 6 | `sections/04_atlas.tex` | 3114 | `9c2e743baf3371fea596ba8b5826edc2dbabfee8fb02593ceaf33f15d2e6addd` |
| 7 | `sections/05_geometry.tex` | 3745 | `9f06f6b82c65bcea457a5eb30ffa13c1547f24c513d106e3da7b123f8757bde4` |
| 8 | `sections/06_validated.tex` | 7964 | `b9a4c6b04981d4d2877aa8e76a17565283a3ecc2e1cdb9afebe463ce93460577` |
| 9 | `sections/07_complete.tex` | 4245 | `21661a7da81c176e144b1d98ee4c2be9a96b53f4ea3bf333f97c18e40015afe1` |
| 10 | `sections/08_microstep.tex` | 6472 | `911dc00352af02b2992ee8d19d508c1a6e30e971e9b8fb3664c2babd3ac1f956` |
| 11 | `sections/09_relationship.tex` | 1783 | `30525ee32757e0228478c51bbe6372b4ebffba5c9d4772699764405ec2d69f11` |
| 12 | `sections/10_interpretation.tex` | 1420 | `31bab6440c53abc2922f19d9b3721d9a8723e332d38be0c357272d3433616b06` |
| 13 | `sections/11_reproducibility.tex` | 10515 | `79868c37ce59f6938fe44b00410d1831741bdb19590d330a4ffbababde58a252` |
| 14 | `sections/12_limitations.tex` | 1617 | `a465b7f9f81e130d50189b9f8f598a7c3b6878efb9b0aed4b0a2148257842079` |
| 15 | `sections/13_conclusion.tex` | 1409 | `1e1c0c374ccfdd36d20729a1ffeb03c610e399cdfce85129145a6f98be7d7af2` |
| 16 | `sections/14_appendix.tex` | 5377 | `c6fa5392312c19f55f0ac31dc3501f16791bb4777ea5b22ff0c89b0005729942` |

## Purpose of each file

- **`README_BUILD.md`** — Build instructions: engine version, dependencies, compilation command, expected output.
- **`main.tex`** — Document class, preamble, macros, title block (`\date{}`), abstract, `\input` list, and the inline `thebibliography` environment with 18 entries.
- **`sections/01_introduction.tex`** — Section 1 — Introduction: problem statement, Eqs. (1)-(2), contributions, local-to-global boundary.
- **`sections/02_model.tex`** — Section 2 — Driven-qubit model and projective response: Eqs. (3)-(10), Definitions 1-2, Remarks 1-2, Proposition 1. Carries fixes 3 and 4.
- **`sections/03_theorems.tex`** — Section 3 — Theorem 1, Theorem 2, Remark 3; Section 4 — analytic reduction (R1)-(R8). Carries fix 2 (Theorem 1(i) scope).
- **`sections/04_atlas.tex`** — Section 6 — Serialized atlas and local proof domain: Eqs. (21)-(25), atlas SHA-256, chart-9 arclength endpoints. Carries fix 7.
- **`sections/05_geometry.tex`** — Section 5 — Geometry of the response fibre: Eqs. (15)-(20), frame matrices, fibre equation, polydisc, Krawczyk graph. Carries fixes 1, 2 and 7.
- **`sections/06_validated.tex`** — Section 7 — Certification machinery: Lemma 1 (Cauchy-Taylor), Eqs. (26)-(34), certificate-scalar and gate table.
- **`sections/07_complete.tex`** — Section 9 — Complementary parent-box certificate: gate table, proof of Theorem 2, Corollaries 1-2, Remark 4. Carries fix 5.
- **`sections/08_microstep.tex`** — Section 8 — Intrinsic ODE microstep certificate: centered mean-value enclosure Eq. (36), Picard enclosure, protocol gate table, proof of Theorem 1.
- **`sections/09_relationship.tex`** — Section 10 — Logical comparison of the two certificates; Proposition 2.
- **`sections/10_interpretation.tex`** — Section 11 — Mathematical-physical interpretation.
- **`sections/11_reproducibility.tex`** — Section 12 — Reproducibility and audit trail: Table 1 (frozen SHA-256 identifiers), Table 2 (direction-safe decimals), parameter conventions. Carries fix 6.
- **`sections/12_limitations.tex`** — Section 13 — Limitations and global-flow outlook: seven exclusions and the local-to-global hierarchy.
- **`sections/13_conclusion.tex`** — Section 14 — Conclusion, data and code availability, conflict of interest.
- **`sections/14_appendix.tex`** — Appendix A — frozen model constants (14 theta_ref values, |t_perp|); Appendix B — computational diagnostics B.1 and B.2, Eq. (37).

## Not included

- No `.bib` file: the bibliography is an inline `thebibliography`
  environment in `main.tex`; no BibTeX or Biber run is required.
- No images: `graphicx` is loaded by the preamble but no
  `\includegraphics` call appears in any source file.
- No local `.sty` or `.cls` file: `main.tex` uses
  `\documentclass{article}` and stock TeX Live packages only.
- Build artifacts (`.aux`, `.log`, `.out`, `.toc`, `.fls`, `.fdb_latexmk`,
  `.synctex.gz`), editor temporaries, and `main.pdf` itself are excluded.
