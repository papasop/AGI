# Build Instructions

This archive is the LaTeX source export for:

`geometric_flow_submission_candidate_v1.1.1_parameter_erratum.pdf`

The compiled PDF being archived separately has SHA-256:

```text
18d11f4fdeef27bf053ab1924b04ec626a51526de9a0e934a84666532d96258a
```

## Engine

The supplied final PDF metadata reports:

```text
Producer: pdfTeX-1.40.25
Creator:  LaTeX with hyperref
```

Use a TeX Live distribution that provides `pdflatex` with pdfTeX 1.40.25 and
the packages listed in `main.tex`.

## Compile

From this directory:

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

No BibTeX or Biber step is required. The bibliography is embedded in
`main.tex` using `thebibliography`.

## External Resources

This manuscript source uses no external image files and no external table
data files. Tables are written directly in LaTeX. No custom `.sty` or `.cls`
files are required; the document uses the standard `article` class and
standard TeX Live packages.

## Scientific Boundary

This is a manuscript source package only. It does not modify theorem-bearing
Python source, frozen certificates, protocol files, input archives, numerical
constants, release tags, or Zenodo records.
