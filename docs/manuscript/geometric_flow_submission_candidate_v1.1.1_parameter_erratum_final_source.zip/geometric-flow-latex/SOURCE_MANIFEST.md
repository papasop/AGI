# Source Manifest

## Primary Entry

- `main.tex`

## Included Section Files

- `sections/01_introduction.tex`
- `sections/02_model.tex`
- `sections/03_theorems.tex`
- `sections/04_atlas.tex`
- `sections/05_geometry.tex`
- `sections/06_validated.tex`
- `sections/07_complete.tex`
- `sections/08_microstep.tex`
- `sections/09_relationship.tex`
- `sections/10_interpretation.tex`
- `sections/11_reproducibility.tex`
- `sections/12_limitations.tex`
- `sections/13_conclusion.tex`
- `sections/14_appendix.tex`

## Bibliography

The bibliography is embedded in `main.tex` with `thebibliography`; no `.bib`
file is used.

## Figures And Tables

There are no external figure files or table-resource files. Tables are
embedded in the LaTeX source.

## Custom Style Or Class Files

No custom `.sty` or `.cls` files are used.

## Expected Final PDF Hash

```text
18d11f4fdeef27bf053ab1924b04ec626a51526de9a0e934a84666532d96258a
```
