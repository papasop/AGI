# Source Manifest

## Primary Entry

- `main.tex`

## Included Section Files

- `sections/01_introduction.tex`
- `sections/02_model.tex`
- `sections/03_theorems.tex`
- `sections/04_atlas.tex`
- `sections/05_geometry.tex`
- `sections/06_validated.tex`
- `sections/07_complete.tex`
- `sections/08_microstep.tex`
- `sections/09_relationship.tex`
- `sections/10_interpretation.tex`
- `sections/11_reproducibility.tex`
- `sections/12_limitations.tex`
- `sections/13_conclusion.tex`
- `sections/14_appendix.tex`

## Bibliography

The bibliography is embedded in `main.tex` with `thebibliography`; no `.bib`
file is used.

## Figures And Tables

There are no external figure files or table-resource files. Tables are
embedded in the LaTeX source.

## Custom Style Or Class Files

No custom `.sty` or `.cls` files are used.

## Reviewed PDF Alignment Notes

This final source export restores the reviewed PDF text for:

- Remark 1, gauge freedom of the reference phase;
- the frozen-task / descent-objective independence paragraph;
- the complex-polydisc Cauchy Lipschitz bound using
  `M = sup ||X||_infinity` and `L <= dM/(R-r)`;
- the Picard gates with `||X||_infinity`;
- Corollary 2 with `ell(.)` the affine arclength coordinate of Eq. (22);
- the child half-width qualification in the Chebyshev coordinate `s`;
- the frozen-code derivative wording `dL6/dell`, not `dL6/ds`.

## Expected Final PDF Hash

```text
18d11f4fdeef27bf053ab1924b04ec626a51526de9a0e934a84666532d96258a
```
