# Source Manifest

Revision: `v1.2.12_freeze_candidate`

Baseline: frozen v1.2.9 manuscript source archive
`geometric_flow_v1_2_9_source.zip`, SHA-256
`6c6d842c8ca6a31631cee3f83e42f52d8accabe34950d8c8683ce457b35b713a`.

Errata source: `docs/MANUSCRIPT_ERRATA_v1.2.9.md`, SHA-256
`1469688fbdf85b2b5af5a8c184e298d0b1186d49030dd0d44b51ee3e1ee91ca2`.

Scope: textual revision only. No Arb rerun. No change to any theorem-bearing
source, input, protocol, certificate, JSON record, atlas, numerical enclosure,
or gate threshold. `GLOBAL_FLOW_CLAIMED` remains `false`.

## Primary Entry

- `main.tex`

## Included Section Files

- `sections/01_introduction.tex`
- `sections/02_model.tex`
- `sections/03_theorems.tex`
- `sections/04_atlas.tex`
- `sections/05_geometry.tex`
- `sections/06_validated.tex`
- `sections/07_complete.tex`
- `sections/08_microstep.tex`
- `sections/09_relationship.tex`
- `sections/10_interpretation.tex`
- `sections/11_reproducibility.tex`
- `sections/12_limitations.tex`
- `sections/13_conclusion.tex`
- `sections/14_appendix.tex`

## Bibliography

The bibliography is embedded in `main.tex` with `thebibliography`; no `.bib`
file is used. References `[1]`-`[18]` are listed in fixed order and are
unchanged from v1.2.9; `[18]` is the Rothman-Ho-Rabitz observable-preserving
homotopy reference.

## Figures And Tables

There are no external figure files or table-resource files. All tables
(Table 1 principal frozen identifiers, Table 2 direction-safe decimals and
their binary64-rendered certificate fields, and the unnumbered gate and
scalar tables of Sections 7.3, 8, 9 and 10) are embedded in the LaTeX source.

## Custom Style Or Class Files

None. The document uses the stock `article` class.

## Build Result

- pages: 20 (A4)
- last displayed equation: (37)
- references: [1]-[18]
- undefined references: 0
- undefined citations: 0
- rerun requests after three passes: 0
- overfull boxes: 0
- underfull boxes: 0

## Changes Relative To v1.2.9

Files unchanged: `sections/01_introduction.tex`, `sections/04_atlas.tex`,
`sections/06_validated.tex`, `sections/09_relationship.tex`,
`sections/10_interpretation.tex`, `sections/12_limitations.tex`,
`sections/13_conclusion.tex`, `sections/14_appendix.tex`.

Files changed:

| File | Change |
|---|---|
| `main.tex` | abstract uniqueness qualified as "within the certified tube"; visible version identifier added |
| `sections/02_model.tex` | added the nominal target-ray generation rule (unnumbered display) |
| `sections/03_theorems.tex` | Theorem 1 stated as an initial-value problem; obligation (R3) rewritten as `BJN` invertibility plus positive definiteness of `H`; dual Stage-A support noted; two certified defect values stated as upper bounds |
| `sections/05_geometry.tex` | declared the complex tangent polydisc and its containment of the real Picard tube; frame matrices described accurately |
| `sections/07_complete.tex` | extremal-child attribution corrected for the curve-speed endpoints |
| `sections/08_microstep.tex` | Picard operator, closed tube, radius, horizon and real-solution remark added; shared outer radius stated; positive-definiteness reasoning completed; normal graph radius labelled a selected parameter; gradient-bound comparison explained |
| `sections/11_reproducibility.tex` | Theorem 2 certificate repository path and asset boundary added to Table 1 and text; Table 2 per-child aggregation annotated; obsolete v0.7.4 parameter labels explicitly withdrawn |

All newly added displayed formulas are unnumbered, so the equation numbering
(1)-(37) of v1.2.9 is preserved exactly.

## Changes In v1.2.11 Relative To v1.2.10

Three textual clarifications, no other edits:

| File | Change |
|---|---|
| `sections/02_model.tex` | reflected analytic extension given explicit coefficients `\bar a_k` (unnumbered display), `\bar z` stated to be the separately propagated extension rather than a pointwise conjugate, and `Re a_k` / `Im a_k` defined as the holomorphic combinations used in the complex-domain enclosures; Remark 1 opening sentence restated so that it does not appear to contradict the fixed representative of Section 2.2 |
| `sections/11_reproducibility.tex` | the defect-value provenance sentence now names the repository-stored certificate file rather than "the shipped release certificate" |
| `main.tex` | visible version identifier updated to v1.2.11 |

These changes introduce no new numbered equation, alter no constant, and
require no Arb rerun.

## Changes In v1.2.12 Relative To v1.2.11

Three textual clarifications, no other edits:

| File | Change |
|---|---|
| `sections/02_model.tex` | Remark 1 closing sentence now asserts phase independence of the theorem-bearing *conclusions* rather than of every scalar |
| `sections/11_reproducibility.tex` | note added after Table 2 assigning its first eight rows to the v0.9.3 certificate and its remaining six rows to the repository-stored v0.7.4 reference certificate |
| `sections/14_appendix.tex` | "shipped v0.7.4 certificate" restated as "repository-stored v0.7.4 certificate file" |

These changes introduce no new numbered equation, alter no constant, and
require no Arb rerun. No displayed equation of v1.2.9 was
edited, renumbered, or removed.

Verified invariant against the v1.2.9 text layer: the Introduction,
Section 11 interpretation, Section 13 limitations, Section 14 conclusion,
Corollary 2, Appendix A and Appendix B.1 are character-identical; every
direction-safe decimal, every binary64 certificate rendering, all fourteen
reference phase values, and all seven Table 1 SHA-256 identifiers occur with
unchanged multiplicity; the Theorem 2 statement differs only by the insertion
of "at most".

## File Checksums

SHA-256 of the files in this archive:

```
f89bf8fd429073b9bac7b5f5527d53265ff0869db11a7ce18a8b8fe8b22c2c31  README_BUILD.md
1a0f2e3702460e31be909d21df089026fe045c1c57a1a45283e920226bd6720c  main.tex
179f9cd79e82a0cd6a0b3059d2065b6438a83f4a1c47521720d5219488767468  sections/01_introduction.tex
79d5bdbdc2e030e0bd27ac88df6d09e7ef39f3b7b61ad4103acfe6bc323a11b0  sections/02_model.tex
18511a82d911ee1b7e08c370d1581662c205f50edd1c4cdb62d5f81a4fa385f6  sections/03_theorems.tex
63e4ceb7cb95378e16f5ee0136f25c5a64453e106c7ab45f2b00eb1b1aa93776  sections/04_atlas.tex
cc4241147543746831679bd086951557edf73ef0f38d40cd66540ede14a407e0  sections/05_geometry.tex
b9a4c6b04981d4d2877aa8e76a17565283a3ecc2e1cdb9afebe463ce93460577  sections/06_validated.tex
f996e9a976f449c4b9236cece28551f2c122a5945e5774bb072282b21133095a  sections/07_complete.tex
911dc00352af02b2992ee8d19d508c1a6e30e971e9b8fb3664c2babd3ac1f956  sections/08_microstep.tex
30525ee32757e0228478c51bbe6372b4ebffba5c9d4772699764405ec2d69f11  sections/09_relationship.tex
31bab6440c53abc2922f19d9b3721d9a8723e332d38be0c357272d3433616b06  sections/10_interpretation.tex
8002bf9a2b7da025337147de57dcf9b1c39e40fa25c7a18b85b8b175635bc355  sections/11_reproducibility.tex
a465b7f9f81e130d50189b9f8f598a7c3b6878efb9b0aed4b0a2148257842079  sections/12_limitations.tex
1e1c0c374ccfdd36d20729a1ffeb03c610e399cdfce85129145a6f98be7d7af2  sections/13_conclusion.tex
c6fa5392312c19f55f0ac31dc3501f16791bb4777ea5b22ff0c89b0005729942  sections/14_appendix.tex
```

`SOURCE_MANIFEST.md` is excluded from the list above because it cannot
contain its own checksum; its SHA-256 is recorded in the accompanying
release/provenance record.
