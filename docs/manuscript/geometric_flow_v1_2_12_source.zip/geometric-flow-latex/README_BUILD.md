# Build Instructions - Manuscript v1.2.12

Revision: `v1.2.12_freeze_candidate`

Title: *Computation as Geometric Flow: An Arb-Certified Local Intrinsic ODE
on a Quantum-Control Response Fibre*

Compiled artifact: `geometric_flow_v1_2_12_freeze_candidate.pdf`

## Nature of this revision

This is a **textual revision only**. It writes the officially recorded
repository errata (`docs/MANUSCRIPT_ERRATA_v1.2.9.md`, SHA-256
`1469688fbdf85b2b5af5a8c184e298d0b1186d49030dd0d44b51ee3e1ee91ca2`) back into
the manuscript body so that the PDF is self-contained.

It does **not** change:

- the mathematical conclusions or numerical constants of Theorem 1 or
  Theorem 2;
- Corollary 1 or Corollary 2 and their constants;
- the definitions of the response map `R3` or the implementation objective `L6`;
- any displayed equation (1)-(37);
- any interval enclosure, direction-safe decimal, or gate threshold;
- the v0.7.4 + v0.9.3 theorem-bearing software boundary;
- any certificate, protocol, JSON record, or atlas;
- the local time interval `0 <= t <= 1e-14`;
- the exclusion of global continuation.

**No Arb rerun was performed and none is required.**

The frozen v1.2.9 manuscript and its source archive remain unchanged and are
not superseded as archival objects.

## Baseline

Derived from the frozen v1.2.9 manuscript source archive:

- `geometric_flow_v1_2_9_source.zip`
- SHA-256: `6c6d842c8ca6a31631cee3f83e42f52d8accabe34950d8c8683ce457b35b713a`

The archive was extracted to a fresh directory; no in-place modification of the
v1.2.9 archive was performed.

## Requirements

- TeX Live 2023 or later with `pdflatex` (reference build used
  pdfTeX 3.141592653-2.6-1.40.25).
- Packages: `graphicx`, `xcolor`, `geometry`, `amsmath`, `amssymb`, `amsthm`,
  `booktabs`, `array`, `enumitem`, `microtype`, `hyperref`, `xurl`.
- No external figure files, no `.bib` file, no custom class or style files.

## Clean build

```sh
cd geometric-flow-latex
pdflatex main.tex
pdflatex main.tex
pdflatex main.tex
```

Three passes are required and sufficient: pass 1 writes `main.aux` and
`main.out`, pass 2 resolves the internal `\ref`/`\eqref`/`\cite` labels, and
pass 3 confirms convergence. After pass 3 the log contains no
"Rerun to get cross-references right" request. If a modified toolchain still
requests a rerun, repeat `pdflatex main.tex` until convergence.

The bibliography is embedded with `thebibliography`; BibTeX/Biber must not be
run.

## Reference build result

| Property | Value |
|---|---|
| pages | 20 |
| page size | A4, 595.276 x 841.89 pt |
| last displayed equation | (37) |
| references | [1]-[18] |
| undefined references | 0 |
| undefined citations | 0 |
| rerun requests after pass 3 | 0 |
| overfull hbox/vbox | 0 |
| underfull hbox/vbox | 0 |

The rebuilt PDF byte hash may differ from any distributed PDF because pdfTeX
regenerates creation-time and document-ID metadata on every run. The
`pdftotext -layout` text layer is the stable comparison surface.

## Relation to v1.2.9

A control build of the unmodified v1.2.9 source with the same toolchain
reproduces the frozen v1.2.9 PDF text layer byte-for-byte. The v1.2.9 to
v1.2.12 text-layer difference consists exactly of the textual revisions
recorded in `SOURCE_MANIFEST.md`, plus the resulting line and page reflow.
