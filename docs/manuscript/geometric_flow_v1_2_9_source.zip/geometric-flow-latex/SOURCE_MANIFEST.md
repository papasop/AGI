# Source Manifest

Revision: `v1.2.9_freeze_candidate`

## Primary Entry

- `main.tex`

## Included Section Files

- `sections/01_introduction.tex`
- `sections/02_model.tex`
- `sections/03_theorems.tex`
- `sections/04_atlas.tex`
- `sections/05_geometry.tex`
- `sections/06_validated.tex`
- `sections/07_complete.tex`
- `sections/08_microstep.tex`
- `sections/09_relationship.tex`
- `sections/10_interpretation.tex`
- `sections/11_reproducibility.tex`
- `sections/12_limitations.tex`
- `sections/13_conclusion.tex`
- `sections/14_appendix.tex`

## Bibliography

The bibliography is embedded in `main.tex` with `thebibliography`; no `.bib`
file is used. References `[1]`-`[18]` are listed in fixed order; `[18]` is the
Rothman-Ho-Rabitz observable-preserving homotopy reference.

## Figures And Tables

There are no external figure files or table-resource files. All tables
(Table 1 principal frozen identifiers, Table 2 direction-safe decimals and
their binary64-rendered certificate fields, and the unnumbered gate and
scalar tables of Sections 7.3, 8, 9 and 10) are embedded in the LaTeX source.

## Custom Style Or Class Files

No custom `.sty` or `.cls` files are used.

## Revision Scope Relative To v1.2.8

Four content repairs and three layout repairs; the Abstract, Introduction,
Theorem 1, Theorem 2, `(R1)`-`(R8)`, the Theorem 2(iii) Cauchy-Schwarz proof
route, the D-MORPH prior-art boundary, the local/global claim boundary,
Appendix A, Appendix B, and the reference order are unchanged.

- Section 12 separates the frozen certificate fields `dL6_dell_upper` and
  `maximum_dL6_dell_upper` from the source quantities `curve_derivative` and
  `loss_derivative`; the non-existent field name `maximum_dL6_dell` is removed.
- Section 8 step (iii) uses `normal-derivative defect`, matching Section 7.3.
- Table 2 gains three proof-bearing constants and the coverage sentence is
  narrowed to the constants the table actually covers.
- Section 8 step (ii) compares the graph utilization against the frozen
  protocol gate `0.95` rather than `1`.
- Table 2 is placed after the source-and-reproduction paragraph so the
  repository URL is no longer split across a page boundary.
- The Section 7.3 and Section 10 tables use explicit column widths; all
  overfull boxes are eliminated.

## Numerical Convention

Every constant quoted from the frozen certificates and used in a theorem or
proof inequality is a direction-safe decimal: lower bounds are truncated
downwards, positive upper bounds are relaxed upwards, and negative upper
bounds are relaxed towards zero. The binary64 certificate renderings are given
in Table 2 and are not exact decimal bounds. No Arb certificate is recomputed
by this revision.

## File SHA-256

```text
a9ab5369363f8b3c31e13efe30751e2ae20835196faabf144ad4d8d85e1d88ec  main.tex
179f9cd79e82a0cd6a0b3059d2065b6438a83f4a1c47521720d5219488767468  sections/01_introduction.tex
c1ba0961c60da2c344e650100b95d44dc16625bb90365ffa12bcac547a8d12f4  sections/02_model.tex
ec28eea311fbbe96de82e25faa69439d92cca44d0bc60f4e5fec1a638f096ce3  sections/03_theorems.tex
63e4ceb7cb95378e16f5ee0136f25c5a64453e106c7ab45f2b00eb1b1aa93776  sections/04_atlas.tex
a7bd8519c634d22f97456e1d1fbf4d376dba1a9123e345a46f3f701aed0e7f79  sections/05_geometry.tex
b9a4c6b04981d4d2877aa8e76a17565283a3ecc2e1cdb9afebe463ce93460577  sections/06_validated.tex
3ea9111dc11a5fbed6e450866b1922865f70095c00e5b84f9465a5b215579727  sections/07_complete.tex
7019b6649c6f148a79d9d27b405a046db9f11a162e400859f93c427b1e7b98de  sections/08_microstep.tex
30525ee32757e0228478c51bbe6372b4ebffba5c9d4772699764405ec2d69f11  sections/09_relationship.tex
31bab6440c53abc2922f19d9b3721d9a8723e332d38be0c357272d3433616b06  sections/10_interpretation.tex
07ef735ae4bcd8dcf36984f47ca3e8c4a7d1c828535264810d302a6b0b55e43f  sections/11_reproducibility.tex
a465b7f9f81e130d50189b9f8f598a7c3b6878efb9b0aed4b0a2148257842079  sections/12_limitations.tex
1e1c0c374ccfdd36d20729a1ffeb03c610e399cdfce85129145a6f98be7d7af2  sections/13_conclusion.tex
4f87ed81d1795604c9b97a6befb314f2a44e887b1f5ca9af0b92e35b22742a4c  sections/14_appendix.tex
```

## Expected Final PDF Hash

```text
1755b3ac6ea6f2efb5115a4b54591083cfbe57a1738b9dac1ca34e211d5760b7
```
