# Build Instructions

This archive is the LaTeX source export for:

`geometric_flow_v1_2_9_freeze_candidate.pdf`

The compiled PDF being archived separately has SHA-256:

```text
1755b3ac6ea6f2efb5115a4b54591083cfbe57a1738b9dac1ca34e211d5760b7
```

## Engine

The reference PDF metadata reports:

```text
Producer: pdfTeX-1.40.25
Creator:  LaTeX with hyperref
```

Use a TeX Live distribution that provides `pdflatex` with pdfTeX 1.40.25 and
the packages listed in `main.tex`.

## Compile

From this directory, run `pdflatex` **three** times:

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

Three passes are required for this revision. Two passes leave 138 undefined
reference/citation warnings and two `Rerun to get cross-references right`
requests; the third pass converges and a fourth pass produces no change.

No BibTeX or Biber step is required. The bibliography is embedded in
`main.tex` using `thebibliography`.

## Expected Build Result

A clean-directory three-pass build produces:

```text
pages                   19
last equation number    (37)
reference range         [1]-[18]
undefined references    0
undefined citations     0
multiply defined labels 0
rerun warnings          0
overfull hbox / vbox    0 / 0
underfull hbox / vbox   0 / 0
```

The compiled byte stream differs between builds only in the pdfTeX
`/CreationDate`, `/ModDate`, and `/ID` metadata. With those three fields
removed, the rebuild reproduces the archived PDF exactly.

## External Resources

This manuscript source uses no external image files and no external table
data files. Tables are written directly in LaTeX. No custom `.sty` or `.cls`
files are required; the document uses the standard `article` class and
standard TeX Live packages.

## Scientific Boundary

This is a manuscript source package only. It does not modify theorem-bearing
Python source, frozen certificates, protocol files, input archives, numerical
constants, release tags, or Zenodo records. The theorem-bearing boundary of
the manuscript remains the frozen v0.7.4 and v0.9.3 artifacts of the
`v0.9.3-validated-ode-microstep` release.
